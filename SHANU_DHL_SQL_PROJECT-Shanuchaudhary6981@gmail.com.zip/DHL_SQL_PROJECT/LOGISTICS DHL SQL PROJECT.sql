CREATE DATABASE dhl_logistics;
USE dhl_logistics;
SHOW TABLES;
SELECT Order_ID, COUNT(*) 
FROM dhl_orders
GROUP BY Order_ID
HAVING COUNT(*) > 1;

SELECT Shipment_ID, COUNT(*) 
FROM dhl_shipments
GROUP BY Shipment_ID
HAVING COUNT(*) > 1;


DESCRIBE dhl_orders;
ALTER TABLE dhl_orders
MODIFY Order_Date DATETIME;

DESCRIBE dhl_orders;
ALTER TABLE dhl_shipments
MODIFY Pickup_Date DATETIME,
MODIFY Delivery_Date DATETIME;
DESCRIBE dhl_shipments;
SELECT Shipment_ID, Pickup_Date, Delivery_Date
FROM dhl_shipments
WHERE Delivery_Date < Pickup_Date;
SELECT COUNT(*) 
FROM dhl_shipments s
LEFT JOIN dhl_orders o ON s.Order_ID = o.Order_ID
WHERE o.Order_ID IS NULL;

SELECT COUNT(*) 
FROM dhl_shipments s
LEFT JOIN dhl_routes r ON s.Route_ID = r.Route_ID
WHERE r.Route_ID IS NULL;

SELECT COUNT(*) 
FROM dhl_shipments s
LEFT JOIN dhl_warehouses w ON s.Warehouse_ID = w.Warehouse_ID
WHERE w.Warehouse_ID IS NULL;

-- TASK 2

SELECT 
    Shipment_ID,
    TIMESTAMPDIFF(HOUR, Pickup_Date, Delivery_Date) AS Actual_Delivery_Hours
FROM dhl_shipments;

 

SELECT Route_ID,round(AVG(Delay_hours),2) AS Avg_delay FROM dhl_shipments
 GROUP BY Route_ID ORDER BY Avg_delay desc limit 10;



SELECT Warehouse_ID,
Shipment_ID,
    Delay_hours,
    RANK() OVER (
        PARTITION BY Warehouse_ID 
        ORDER BY Delay_hours DESC
    ) AS Delay_Rank
FROM dhl_shipments;


SELECT 
    o.Delivery_Type,
    ROUND(AVG(s.Delay_hours), 2) AS Avg_Delay_Hours
FROM dhl_shipments s
JOIN dhl_orders o
    ON s.Order_ID = o.Order_ID
GROUP BY o.Delivery_Type;

-- TASK 3

SELECT * FROM dhl_shipments;

SELECT 
    ROUND(AVG(TIMESTAMPDIFF(HOUR, Pickup_Date, Delivery_Date)), 2)
        AS Avg_Transit_Time_Hours
FROM dhl_shipments;

SELECT
    Route_ID,
    ROUND(AVG(Delay_hours), 2) AS Avg_Delay_Hours
FROM dhl_shipments
GROUP BY Route_ID;

SELECT
    r.Route_ID,
    ROUND(
        r.Distance_KM / AVG(TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)),
        2
    ) AS Efficiency_Ratio
FROM dhl_shipments s
JOIN dhl_routes r
    ON s.Route_ID = r.Route_ID
GROUP BY r.Route_ID, r.Distance_KM;

select * from dhl_routes;
SELECT
    r.Route_ID,
    ROUND(
        r.Distance_KM / AVG(TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)),
        2
    ) AS Efficiency_Ratio
FROM dhl_shipments s
JOIN dhl_routes r
    ON s.Route_ID = r.Route_ID
GROUP BY r.Route_ID, r.Distance_KM
ORDER BY Efficiency_Ratio ASC
LIMIT 3;


SELECT
    s.Route_ID,
    ROUND(
        SUM(
            CASE 
                WHEN TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date) 
                     > r.Avg_Transit_Time_Hours 
                THEN 1 ELSE 0 
            END
        ) * 100.0 / COUNT(*),
        2
    ) AS Delayed_Percentage
FROM dhl_shipments s
JOIN dhl_routes r
    ON s.Route_ID = r.Route_ID
GROUP BY s.Route_ID
HAVING Delayed_Percentage > 20;


SELECT s.Route_ID, s.Warehouse_ID, ROUND(AVG(TIMESTAMPDIFF(HOUR, s.Pickup_Date, s.Delivery_Date)), 2) AS Avg_Transit_Hours,
ROUND(AVG(s.Delay_Hours), 2) AS Avg_Delay_Hours
FROM dhl_shipments s
GROUP BY s.Route_ID, s.Warehouse_ID
ORDER BY Avg_Delay_Hours DESC;

-- TASK 4

SELECT
    Warehouse_ID,
    ROUND(AVG(Delay_Hours), 2) AS Avg_Delay_Hours
FROM dhl_shipments
GROUP BY Warehouse_ID
ORDER BY Avg_Delay_Hours DESC
LIMIT 3;

SELECT
    Warehouse_ID,
    COUNT(*) AS Total_Shipments,
    SUM(CASE WHEN Delay_Hours > 0 THEN 1 ELSE 0 END) AS Delayed_Shipments
FROM dhl_shipments
GROUP BY Warehouse_ID;

WITH global_avg AS (
    SELECT AVG(Delay_Hours) AS avg_delay
    FROM dhl_shipments
)
SELECT
    s.Warehouse_ID,
    ROUND(AVG(s.Delay_Hours), 2) AS Warehouse_Avg_Delay
FROM dhl_shipments s
CROSS JOIN global_avg
GROUP BY s.Warehouse_ID
HAVING AVG(s.Delay_Hours) > (SELECT avg_delay FROM global_avg);

SELECT Warehouse_ID, ROUND(SUM(CASE WHEN Delay_hours = 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*),2) AS On_Time_Percentage,
    RANK() OVER (ORDER BY SUM(CASE WHEN Delay_hours = 0 THEN 1 ELSE 0 END) * 1.0 / COUNT(*) DESC) AS Warehouse_Rank
FROM dhl_shipments
GROUP BY Warehouse_ID;


-- TASK 5

SELECT
    s.Route_ID,
    s.Agent_ID,
    ROUND(
        SUM(CASE WHEN s.Delay_hours = 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*),
        2
    ) AS On_Time_Percentage,
    RANK() OVER (
        PARTITION BY s.Route_ID
        ORDER BY
        SUM(CASE WHEN s.Delay_hours = 0 THEN 1 ELSE 0 END) * 1.0 / COUNT(*) DESC
    ) AS Agent_Rank
FROM dhl_shipments s
GROUP BY s.Route_ID, s.Agent_ID;


SELECT
    s.Agent_ID,
    ROUND(
        SUM(CASE WHEN s.Delay_hours = 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*),
        2
    ) AS On_Time_Percentage
FROM dhl_shipments s
GROUP BY s.Agent_ID
HAVING On_Time_Percentage < 85;

-- Top 5 vs Bottom 5

WITH Agent_Performance AS (
    SELECT
        a.Agent_ID,
        a.Avg_Rating,
        a.Experience_Years,
        SUM(CASE WHEN s.Delay_hours = 0 THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS On_Time_Ratio
    FROM dhl_shipments s
    JOIN dhl_delivery_agents a
        ON s.Agent_ID = a.Agent_ID
    GROUP BY a.Agent_ID, a.Avg_Rating, a.Experience_Years
),
Top5 AS (
    SELECT * FROM Agent_Performance
    ORDER BY On_Time_Ratio DESC
    LIMIT 5
),
Bottom5 AS (
    SELECT * FROM Agent_Performance
    ORDER BY On_Time_Ratio ASC
    LIMIT 5
)
SELECT
    'Top 5 Agents' AS Group_Type,
    ROUND(AVG(Avg_Rating),2) AS Avg_Rating,
    ROUND(AVG(Experience_Years),2) AS Avg_Experience
FROM Top5
UNION ALL
SELECT
    'Bottom 5 Agents',
    ROUND(AVG(Avg_Rating),2),
    ROUND(AVG(Experience_Years),2)
FROM Bottom5;

-- Task 6


SELECT
    Shipment_ID,
    Delivery_Status AS Latest_Status,
    Delivery_Date AS Latest_Delivery_Date
FROM dhl_shipments
WHERE (Shipment_ID, Delivery_Date) IN (SELECT Shipment_ID, MAX(Delivery_Date)
    FROM dhl_shipments
    GROUP BY Shipment_ID);


SELECT
    Route_ID,
    ROUND(
        SUM(CASE 
                WHEN Delivery_Status IN ('In Transit', 'Returned') 
                THEN 1 ELSE 0 
            END) * 100.0 / COUNT(*),
        2
    ) AS Not_Delivered_Percentage
FROM dhl_shipments
GROUP BY Route_ID
HAVING Not_Delivered_Percentage > 50;

SELECT
    Delay_Reason,
    COUNT(*) AS Occurrences
FROM dhl_shipments
WHERE Delay_Reason IS NOT NULL
GROUP BY Delay_Reason
ORDER BY Occurrences DESC;

SELECT
    Shipment_ID,
    Route_ID,
    Warehouse_ID,
    Delay_Hours
FROM dhl_shipments
WHERE Delay_Hours > 120
ORDER BY Delay_Hours DESC;

-- Task 7
SELECT
    r.Source_Country,
    ROUND(AVG(s.Delay_Hours), 2) AS Avg_Delay_Hours
FROM dhl_shipments s
JOIN dhl_routes r ON s.Route_ID = r.Route_ID
GROUP BY r.Source_Country;

SELECT
    ROUND(
        SUM(CASE WHEN Delay_Hours = 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*),
        2
    ) AS On_Time_Delivery_Percentage
FROM dhl_shipments;

SELECT
    Route_ID,
    ROUND(AVG(Delay_Hours), 2) AS Avg_Delay_Hours
FROM dhl_shipments
GROUP BY Route_ID;

SELECT
    w.Warehouse_ID,
    ROUND(
        COUNT(s.Shipment_ID) * 100.0 / w.Capacity_per_day,
        2
    ) AS Warehouse_Utilization_Percentage
FROM dhl_shipments s
JOIN dhl_warehouses w ON s.Warehouse_ID = w.Warehouse_ID
GROUP BY w.Warehouse_ID, w.Capacity_per_day;
